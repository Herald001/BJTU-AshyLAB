function [f, F_x, F_u] = transitionFunction(x,u, b)
% [f, F_x, F_u] = transitionFunction(x,u,b) predicts the state x at time t given
% the state at time t-1 and the input u at time t. F_x denotes the Jacobian
% of the state transition function with respect to the state evaluated at
% the state and input provided. F_u denotes the Jacobian of the state
% transition function with respect to the input evaluated at the state and
% input provided.
% State and input are defined according to "Introduction to Autonomous Mobile Robots", pp. 337

% 中间变量简化公式
theta = x(3);
delta_s = (u(1) + u(2)) / 2;
delta_theta = (u(2) - u(1)) / b;
theta_c = theta + delta_theta / 2;

f = x + [delta_s * cos(theta_c);
         delta_s * sin(theta_c);
         delta_theta];

F_x = [1, 0, -delta_s * sin(theta_c);
       0, 1,  delta_s * cos(theta_c);
       0, 0,  1];

F_u = [cos(theta_c) / 2 + (delta_s * sin(theta_c)) / (2 * b), ...
       cos(theta_c) / 2 - (delta_s * sin(theta_c)) / (2 * b);
       sin(theta_c) / 2 - (delta_s * cos(theta_c)) / (2 * b), ...
       sin(theta_c) / 2 + (delta_s * cos(theta_c)) / (2 * b);
       -1 / b, 1 / b];
end

