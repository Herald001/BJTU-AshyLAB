function [img] = bob_getMap(connection)

    if (connection.robotNb==0)
        [result,h]=connection.vrep.simxGetObjectHandle(connection.clientID,'Bob_mapSensor',connection.vrep.simx_opmode_oneshot_wait);
    else
        [result,h]=connection.vrep.simxGetObjectHandle(connection.clientID,strcat('Bob_mapSensor',num2str(connection.robotNb-1)),connection.vrep.simx_opmode_oneshot_wait);
    end
    if (result~=connection.vrep.simx_error_noerror)
        err = MException('VREP:RemoteApiError', ...
            'simxGetObjectHandle failed');
        throw(err);
    end
    [result,resolution,img]=connection.vrep.simxGetVisionSensorImage2(connection.clientID,h,1,connection.vrep.simx_opmode_oneshot_wait);
    img=mat2gray(img);
    if (result~=connection.vrep.simx_error_noerror)
        err = MException('VREP:RemoteApiError', ...
            'simxGetVisionSensorImage2 failed');
        throw(err);
    end
    
end