function bob_addPathSegment(connection,x0,y0,x1,y1)

    signalValue=connection.vrep.simxPackFloats([x0,y0,x1,y1]);
    connection.vrep.simxSetStringSignal(connection.clientID,strcat('Bob_reqAddPathSeg',num2str(connection.robotNb)),signalValue,connection.vrep.simx_opmode_oneshot);

end