function bob_clearMapSegments(connection)

    connection.vrep.simxSetIntegerSignal(connection.clientID,strcat('Bob_reqClearMapSeg',num2str(connection.robotNb)),0,connection.vrep.simx_opmode_oneshot);

end