function bob_setWheelSpeeds(connection,leftInRadPerSec,rightInRadPerSec)

    signalValue=connection.vrep.simxPackFloats([leftInRadPerSec,rightInRadPerSec]);
    connection.vrep.simxSetStringSignal(connection.clientID,strcat('Bob_reqVelocities',num2str(connection.robotNb)),signalValue,connection.vrep.simx_opmode_oneshot);

end