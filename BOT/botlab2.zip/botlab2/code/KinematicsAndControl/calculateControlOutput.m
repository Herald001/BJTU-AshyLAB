function [ vu, omega ] = calculateControlOutput( robotPose, goalPose, parameters )
    %CALCULATECONTROLOUTPUT This function computes the motor velocities for a differential driven robot

    % current robot position and orientation
    x = robotPose(1);
    y = robotPose(2);
    theta = robotPose(3);

    % goal position and orientation
    xg = goalPose(1);
    yg = goalPose(2);
    thetag = goalPose(3);

    % compute control quantities
    rho = sqrt((xg-x)^2+(yg-y)^2);  % pythagoras theorem, sqrt(dx^2 + dy^2)
    lambda = atan2(yg-y, xg-x);     % angle of the vector pointing from the robot to the goal in the inertial frame
    alpha = lambda - theta;         % angle of the vector pointing from the robot to the goal in the robot frame
    alpha = normalizeAngle(alpha);
    beta = thetag - lambda;
    beta = normalizeAngle(beta);
    % the following paramerters should be used:
    % Task 2:
    % parameters.Kalpha, parameters.Kbeta, parameters.Krho: controller tuning
    % parameters
    %==================================
%     vu = parameters.Krho * rho; % [m/s]
%     omega = parameters.Kalpha * alpha + parameters.Kbeta * beta; % [rad/s]
    %==================================
    % Task 3:
    % parameters.backwardAllowed: This boolean variable should switch the between the two controllers
    % parameters.useConstantSpeed: Turn on constant speed option
    % parameters.constantSpeed: The speed used when constant speed option is on

    % % complete the following code.
    flag = 1;  % Default to forward motion
    if parameters.backwardAllowed
        if abs(alpha) > pi/2
            flag = -1;  % Set flag for backward motion
            alpha = alpha - pi/2;  % Adjust angle for backward motion
            beta = beta - pi/2;    % Adjust beta for backward motion
        end
    end
    if parameters.useConstantSpeed
        vu = flag * parameters.constantSpeed;
        omega = (vu / (parameters.Krho * rho)) * (parameters.Kalpha * alpha + parameters.Kbeta * beta);
    else
        vu = flag * parameters.Krho * rho;
        omega = flag * (parameters.Kalpha * alpha + parameters.Kbeta * beta);
    end
end
     



