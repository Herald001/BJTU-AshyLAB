function bob_setTargetGhostVisible(connection,visible)

    connection.vrep.simxSetIntegerSignal(connection.clientID,strcat('Bob_reqTargetGhostVisibility',num2str(connection.robotNb)),visible,connection.vrep.simx_opmode_oneshot);

end