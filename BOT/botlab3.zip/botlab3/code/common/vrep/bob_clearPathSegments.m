function bob_clearPathSegments(connection)

    connection.vrep.simxSetIntegerSignal(connection.clientID,strcat('Bob_reqClearPathSeg',num2str(connection.robotNb)),0,connection.vrep.simx_opmode_oneshot);

end