% Input:   XY - [2,N]: X,Y coordinates
%          LINE_POINT_DIST_THRESHOLD [1, 1]: point distance threshold. Where it is exceeded a split is performed
% Output:  alpha - [NLines]: line parameters       
%          r - [NLines]: line parameters
%          segend [NLines, 4] : segment's end point coordinates
%          seglen [NLines, 1] : segment's length
%          pointIdx [NLines, 2] : segment's first and last point index in XY

function [alpha, r, segend, seglen, pointIdx] = extractLines(XY, params)
    % Extract line segments
    [alpha, r, pointIdx] = splitLinesRecursive(XY, 1, size(XY, 2), params);
  
    N = length(r);
    if (N > 1) 
        [alpha, r, pointIdx] = mergeColinearNeigbors(XY, alpha, r, pointIdx, params);
        N = length(r);
    end
    
    % Compute endpoints/lengths of the segments
    segend = zeros(N, 4);
    seglen = zeros(N, 1);
    for i=1:N
        segend(i, :) = [XY(:, pointIdx(i,1))' XY(:, pointIdx(i,2))'];
        % Length
        seglen(i) = sqrt((segend(i,1) - segend(i,3))^2 + (segend(i,2) - segend(i,4))^2);
    end

    % Removing short segments
    goodSegIdx = find((seglen >= params.MIN_SEG_LENGTH) & ((pointIdx(:, 2) - pointIdx(:, 1)) >= params.MIN_POINTS_PER_SEGMENT));
    pointIdx = pointIdx(goodSegIdx, :);
    alpha = alpha(goodSegIdx);
    r = r(goodSegIdx);
    segend = segend(goodSegIdx, :);
    seglen = seglen(goodSegIdx);
end
%--------------------------------------------------------------------
% Main splitting function
function [alpha, r, idx] = splitLinesRecursive(XY, startIdx, endIdx, params)
% Number of input points
    N = endIdx - startIdx + 1;
  
    % Fit a line using the N points
    [alpha, r] = fitLine(XY(:, startIdx:endIdx));
  
    if (N <= 2)
        idx = [startIdx, endIdx];        
        return;
    end
  
    % Find the splitting position (if there is)
    splitPos = findSplitPos(XY(:, startIdx:endIdx), alpha, r, params);
  
    if (splitPos ~= -1) % found a splitting point
        [alpha1, r1, idx1] = splitLinesRecursive(XY, startIdx, splitPos+startIdx-1, params);
        [alpha2, r2, idx2] = splitLinesRecursive(XY, splitPos+startIdx-1, endIdx, params);
        alpha = [alpha1; alpha2];
        r = [r1; r2];
        idx = [idx1; idx2];
    else % no need to split
        idx = [startIdx, endIdx];
    end
    return  % function splitLinesRecursive
end

%---------------------------------------------------------------------
function splitPos = findSplitPos(XY, alpha, r, params)
    % Compute the distances from the points to the fitted line
    d = compDistPointsToLine(XY, alpha, r);

    % Find the splitting position (if there is)
    splitPos = findSplitPosInD(d, params);
end

% ---------------------------------------------------------------------
% This function computes the distances from the input points to
% an input line.
% Note that here we can have negative values for distances (to indicate
% which side relative to the line the point belongs).
% Input:   XY - [2,N] : input points
%          alpha, r : line parameters
% Output:  d - [N]: the distances from the input points to the line.

function d = compDistPointsToLine(XY, alpha, r)
    cosA = cos(alpha);
    sinA = sin(alpha);
   
    xcosA = XY(1,:) * cosA;
    ysinA = XY(2,:) * sinA;
    d = xcosA + ysinA - r; % 计算点到线的距离
end
%---------------------------------------------------------------------
% function splitPos = findSplitPosInD(d, params)
%     % d：所有离散点到线的距离集合
%     cnt = length(d);  % 点的数量
%     splitPos = -1; % 初始化分割点
%     max = -1; % 最大误差
%     % 去找到距离误差最大的点
%     for i = 2:cnt
%         if (abs(d(i)) > params.LINE_POINT_DIST_THRESHOLD)
%             if (abs(d(i)) > max)
%                 max = abs(d(i));
%                 splitPos = i;
%             end
%        end
%     end
% if splitPos==1,splitPos=splitPos+1;end
% if splitPos==length(d),splitPos=splitPos-1;end
% end
function splitPos = findSplitPosInD(d, params)
    cnt = length(d);  % 获取点的数量
    splitPos = -1;  % 初始化分割点
    neighbors = [];  % 初始化邻居点数组

    % 找到大于阈值的邻居点
    for i = 1:cnt-1
        if (abs(d(i)) > params.LINE_POINT_DIST_THRESHOLD) &&...
           (abs(d(i+1)) > params.LINE_POINT_DIST_THRESHOLD) &&...
           (d(i) * d(i+1) > 0)
                neighbors(end + 1) = i;  % 添加到邻居数组
        end
    end
    
    % 如果有邻居点，计算最大邻居点对的绝对值和
    if ~isempty(neighbors)
        maxSum = -1;  % 初始化最大和
        for i = 1:length(neighbors)
            idx = neighbors(i);
            pairSum = abs(d(idx)) + abs(d(idx + 1));
            
            if pairSum > maxSum
                maxSum = pairSum;
                splitPos = idx; 
            end
        end
        
        if splitPos ~= -1 && abs(d(splitPos)) < abs(d(splitPos + 1))
            splitPos = splitPos + 1;
        end
    end
    % 边界条件处理
   if splitPos ~= -1 && (splitPos < 3 || splitPos > cnt-2)
        maxValue = -1;  % 初始化最大值
       for i = 1:cnt
            if abs(d(i)) > maxValue
                maxValue = abs(d(i));
                splitPos = i;  % 更新分割点
            end
       end
       if splitPos == 1,splitPos = splitPos + 1;
       elseif splitPos == cnt,splitPos = splitPos - 1;end
   end   
end

    

%---------------------------------------------------------------------

function [alphaOut, rOut, pointIdxOut] = mergeColinearNeigbors (XY, alpha, r, pointIdx, params)
    z = [alpha(1), r(1)];
    startIdx = pointIdx(1, 1);
    lastEndIdx = pointIdx(1, 2);
    
    rOut = [];
    alphaOut = [];
    pointIdxOut = [];

    j = 1;
    N = size(r, 1);
    for i = 2:N
        endIdx = pointIdx(i, 2);
        
        [zt(1), zt(2)] = fitLine(XY(:, startIdx : endIdx));
              
        % Find the splitting position in merged segment (if there is)
        splitPos = findSplitPos(XY(:, startIdx:endIdx), zt(1), zt(2), params);

        if (splitPos == -1) % no split necessary, so we finally merge
            z = zt;
        else % no further merging
            alphaOut(j, 1) = z(1);
            rOut(j, 1) = z(2);
            pointIdxOut(j, :) = [startIdx, lastEndIdx];
            j = j + 1;
            z = [alpha(i), r(i)];
            startIdx = pointIdx(i, 1);
        end
        lastEndIdx = endIdx;
    end
    % add last segment
    alphaOut(j, 1) = z(1);
    rOut(j, 1) = z(2);
    pointIdxOut(j, :) = [startIdx, lastEndIdx];
end
