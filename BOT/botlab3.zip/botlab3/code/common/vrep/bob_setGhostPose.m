function bob_setGhostPose(connection,x,y,gamma)

    signalValue=connection.vrep.simxPackFloats([x,y,gamma]);
    connection.vrep.simxSetStringSignal(connection.clientID,strcat('Bob_reqGhostPose',num2str(connection.robotNb)),signalValue,connection.vrep.simx_opmode_oneshot);

end